windowWidth = 800;
windowHeight = 800;

--GameObject* temp = gom->FindObjectOfTag("Player");